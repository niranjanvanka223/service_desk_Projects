-- Practice schema and fictional sample data for MySQL.
-- Run in a test database only. No real customer data is included.

CREATE DATABASE IF NOT EXISTS service_desk_case_study;
USE service_desk_case_study;

DROP TABLE IF EXISTS support_requests;
CREATE TABLE support_requests (
    request_id VARCHAR(20) PRIMARY KEY,
    requester_name VARCHAR(80),
    category VARCHAR(40),
    status VARCHAR(30),
    priority VARCHAR(5),
    created_at DATE,
    assigned_team VARCHAR(80)
);

INSERT INTO support_requests
(request_id, requester_name, category, status, priority, created_at, assigned_team)
VALUES
('SD-1001', 'Demo User A', 'Access', 'Escalated', 'P1', '2026-10-01', 'Access Support'),
('SD-1002', 'Demo User B', 'Performance', 'In Progress', 'P3', '2026-10-02', 'Application Support'),
('SD-1003', 'Demo User C', 'Data Quality', 'Logged', 'P4', '2026-10-03', 'Service Desk'),
('SD-1004', 'Demo User D', 'Availability', 'Escalated', 'P1', '2026-10-04', 'Service Desk Lead');

DROP TABLE IF EXISTS request_updates;
CREATE TABLE request_updates (
    update_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(20),
    update_date DATE,
    update_note VARCHAR(255),
    FOREIGN KEY (request_id) REFERENCES support_requests(request_id)
);

INSERT INTO request_updates (request_id, update_date, update_note)
VALUES
('SD-1001', '2026-10-01', 'Routed to access support for triage'),
('SD-1002', '2026-10-02', 'Reproduction and performance checks pending'),
('SD-1004', '2026-10-04', 'Critical service-impact workflow initiated');
