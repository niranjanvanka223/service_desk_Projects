USE service_desk_case_study;

-- 1. Review all logged requests.
SELECT request_id, category, status, priority, created_at
FROM support_requests
ORDER BY created_at DESC;

-- 2. Find high-priority requests that may need escalation review.
SELECT request_id, category, status, assigned_team
FROM support_requests
WHERE priority IN ('P1', 'P2');

-- 3. Count requests by category.
SELECT category, COUNT(*) AS request_count
FROM support_requests
GROUP BY category
ORDER BY request_count DESC;

-- 4. Join requests to their update history.
SELECT r.request_id, r.category, r.status, u.update_date, u.update_note
FROM support_requests AS r
LEFT JOIN request_updates AS u
    ON r.request_id = u.request_id
ORDER BY r.request_id, u.update_date;

-- 5. Check for requests missing an assigned team.
SELECT request_id, category, status
FROM support_requests
WHERE assigned_team IS NULL OR TRIM(assigned_team) = '';

-- 6. Check for duplicate IDs (normally prevented by the primary key).
SELECT request_id, COUNT(*) AS id_count
FROM support_requests
GROUP BY request_id
HAVING COUNT(*) > 1;
