# Sample Request Logging Workflow

1. **Receive** the request through the approved support channel.
2. **Validate** the required information; do not request or record passwords.
3. **Log** a unique request ID, concise summary, service, timestamp, and requester details permitted by policy.
4. **Categorize** the request (for example: access, application, connectivity, data, or service availability).
5. **Assess impact and urgency** using the organization's priority matrix.
6. **Document** checks already performed and the user's observed symptoms.
7. **Route or escalate** using the documented procedure, especially for critical or widespread impact.
8. **Track** ownership, status, updates, and next action.
9. **Confirm resolution** with the requester where required, record the outcome, and close according to the process.

> This is a generic learning workflow. Always follow the actual employer's SOP, severity definitions, security policies, and escalation matrix.
