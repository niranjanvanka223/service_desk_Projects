# Incident Notes Template

- **Request / ticket ID:**
- **Date and time reported:**
- **Requester / affected group:** Use fictional or anonymized details.
- **Service or application:**
- **Issue summary:**
- **Observed behavior:**
- **Expected behavior:**
- **Impact and urgency:**
- **Priority and rationale:**
- **Checks / troubleshooting performed:**
- **Evidence captured:** Avoid passwords, tokens, personal data, and secrets.
- **Current status:**
- **Escalated to / reason:**
- **Handoff notes:**
- **Next action / owner:**
- **Last updated:**

## Example note (fictional)

Users report that the demo sign-in page rejects a test account. Confirmed the issue can be reproduced in the demo environment. No password or personal information recorded. Categorized as Access and marked high priority for triage; routed to the appropriate support queue for further investigation.
