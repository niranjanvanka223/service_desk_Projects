# API Troubleshooting Checklist

## Before testing
- Confirm the endpoint, HTTP method, and test environment.
- Confirm required headers and request parameters.
- Never paste credentials, API keys, access tokens, or private customer data into a public repository.

## Inspect the response
- HTTP status code and response time.
- Response body format (JSON, text, or empty).
- Expected fields and data types.
- Error message, if present.
- Whether the result is reproducible.

## Record the issue
- Test ID and timestamp.
- Endpoint and method.
- Expected result versus actual result.
- Sanitized evidence and steps to reproduce.
- Impact, current status, and next action.

## After a change
- Repeat the same request.
- Record the actual retest result.
- Check for related regressions.
- Update the ticket or handoff notes.

The included Postman collection uses JSONPlaceholder, a public demo API. Results may vary if the service changes; record what you actually observe.
